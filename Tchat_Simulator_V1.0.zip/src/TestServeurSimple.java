public class TestServeurSimple
{
	public static void main(String[] args)
	{
		ServeurSimple server;

		server = new ServeurSimple();
	}
}
